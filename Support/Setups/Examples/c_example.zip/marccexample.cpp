#include <stdio.h>
#include <marc.h>

#define ERROR_STR_LENGTH 200

int i_Count = 0;

void DisplayError(Response res)
{
	char zBuff[ERROR_STR_LENGTH + 1];
	ResponseToStr(res,zBuff,ERROR_STR_LENGTH);
	printf("%s\n",zBuff);
}

void DisplayInfo(RobotInfo * info)
{
	printf("Health: %d\n",info->i_Health);
	printf("Battery: %d\n",info->i_Battery);
	printf("Score: %d\n",info->i_Score);
}

Response PickupAll(Picture * pic)
{
	for (int i = 0 ; i < PICTURE_HEIGHT ; i ++)
	{
		for (int j = 0 ; j < PICTURE_WIDTH ; j++)
		{
			ObjectType obt = GetObjectTypeAt(i,j,pic);
			if ((obt == OT_YELLOW_PACKAGE) || (obt == OT_PINK_PACKAGE) || (obt == OT_BROWN_PACKAGE) || (obt == OT_BATTERY_PACK))
			{
				Response res;
				if ((res = PickupPackage(i,j,"")) != ACTION_SUCCESSFUL)
					return res;
			}
		}
	}
	return ACTION_SUCCESSFUL;
}

int GetMaxAfterPick(Picture * pic)
{
	int iLength = 5;
	for (int i = 0 ; i < PICTURE_HEIGHT ; i++)
	{
		for (int j = (PICTURE_WIDTH - 1) ; j >= 0 ; j--)
		{
			ObjectType obt = GetObjectTypeAt(i,j,pic);
			if (!((obt == OT_NONE) || (obt == OT_TELEPORT_BEAM) || (obt == OT_YELLOW_PACKAGE) || (obt == OT_PINK_PACKAGE) || (obt == OT_BROWN_PACKAGE) || (obt == OT_BATTERY_PACK)))
			{
				if (iLength > (PICTURE_HEIGHT - 1 - j))
					iLength = PICTURE_HEIGHT - 1 - j;
				break;
			}
		}
	}
	return iLength;
}

Response PickupAll(int * iNextCount)
{
	Response res;

	Picture picNorth;
	if ((res = TakePicture(&picNorth)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(&picNorth)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = Turn(DEGREES_MINUS_90)) != ACTION_SUCCESSFUL)
		return res;

	Picture picWest;
	if ((res = TakePicture(&picWest)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(&picWest)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = Turn(DEGREES_180)) != ACTION_SUCCESSFUL)
		return res;

	Picture picEast;
	if ((res = TakePicture(&picEast)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(&picEast)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = Turn(DEGREES_MINUS_90)) != ACTION_SUCCESSFUL)
		return res;

	*iNextCount = GetMaxAfterPick(&picNorth);
	return ACTION_SUCCESSFUL;
}

Response RunGame()
{
	Response res;
	int iCount = 0;
	while(true)
	{
		if ((res = PickupAll(&iCount)) != ACTION_SUCCESSFUL)
			return res;
		else
		{
			if (iCount == 0)
			{
				if ((res = Turn(DEGREES_180)) != ACTION_SUCCESSFUL)
					return res;
				else
				{
					if ((res = Move(i_Count)) != ACTION_SUCCESSFUL)
						return res;
					else
						return ACTION_SUCCESSFUL;
				}
			}
			else
			{
				if ((res = Move(iCount)) != ACTION_SUCCESSFUL)
					return res;
				i_Count = i_Count + iCount;
			}
		}
	}
	return ACTION_SUCCESSFUL;
}

void main()
{
	Response res;
	if ((res = StartMission()) != ACTION_SUCCESSFUL)
	{
		DisplayError(res);
		return;
	}

	if ((res = RunGame()) != ACTION_SUCCESSFUL)
	{
		DisplayError(res);
		return;
	}

	RobotInfo info;
	if ((res = EndMission(&info)) != ACTION_SUCCESSFUL)
	{
		DisplayError(res);
		return;
	}
	DisplayInfo(&info);
}
