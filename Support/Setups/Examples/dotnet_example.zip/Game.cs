using System;
using marc;

namespace marcdotnetexample
{
	class Game
	{
		private uint count;

		Game()
		{
			count = 0;
		}

		private void PickupPackage(Robot robot,uint i,uint j,String tag)
		{
			try
			{
				robot.PickupPackage(i,j,tag);
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
		}

		private Picture TakePicture(Robot robot)
		{
			Picture pic;
			try
			{
				pic = robot.TakePicture();
				return pic;
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(UnknownErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			return null;
		}

		private void Turn(Robot robot,Angle ang)
		{
			try
			{
				robot.Turn(ang);
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(UnknownErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
		}

		private void Move(Robot robot,uint length)
		{
			try
			{
				robot.Move(length);
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(UnknownErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
		}

		private void StartMission(Robot robot)
		{
			try
			{
				robot.StartMission();
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(UnknownErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
		}

		private void EndMission(Robot robot)
		{
			try
			{
				RobotInfo info = robot.EndMission();
				DisplayInfo(info);
			}
			catch(CommunicationFailedException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(CommunicationErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(DisqualifiedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(ActionFailedExeption e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
			catch(UnknownErrorException e)
			{
				System.Console.WriteLine(e.Message);
				System.Environment.Exit(0);
			}
		}

		private void PickupAll(Robot robot,Picture pic)
		{
			uint iEnd = Picture.WIDTH;
			uint jEnd = Picture.HEIGHT;
	
			for (uint i = 0 ; i < iEnd ; i ++)
			{
				for (uint j = 0 ; j < jEnd ; j++)
				{
					ObjectType obt = pic.GetObjectTypeAt(i,j);
					if ((obt == ObjectType.OT_YELLOW_PACKAGE)
						|| (obt == ObjectType.OT_PINK_PACKAGE)
						|| (obt == ObjectType.OT_BROWN_PACKAGE)
						|| (obt == ObjectType.OT_BATTERY_PACK))
					{
						PickupPackage(robot,i,j,"");
					}
				}
			}
		}	

		private void DisplayInfo(RobotInfo info)
		{
			System.Console.WriteLine("Health: " + info.HEALTH);
			System.Console.WriteLine("Battery: " + info.BATTERY);
			System.Console.WriteLine("Score: " + info.SCORE);
		}

		private uint GetMaxAfterPick(Picture pic)
		{
			uint iEnd = Picture.WIDTH;
			uint jEnd = Picture.HEIGHT;

			uint iLength = 5;

			for (uint i = 0 ; i < iEnd ; i++)
			{
				for (uint j = (jEnd - 1) ; j >= 0 ; j--)
				{
					ObjectType obt = pic.GetObjectTypeAt(i,j);
					if (!((obt == ObjectType.OT_NONE)
						|| (obt == ObjectType.OT_TELEPORT_BEAM)
						|| (obt == ObjectType.OT_YELLOW_PACKAGE)
						|| (obt == ObjectType.OT_PINK_PACKAGE)
						|| (obt == ObjectType.OT_BROWN_PACKAGE)
						|| (obt == ObjectType.OT_BATTERY_PACK)))
					{
						if (iLength > (jEnd - 1 - j))
							iLength = jEnd - 1 - j;
						break;
					}
				}
			}
			return iLength;
		} 

		private uint PickupAll(Robot robot)
		{
			Picture picNorth = TakePicture(robot);
			PickupAll(robot,picNorth);
			Turn(robot,Angle.DEGREES_MINUS_90);
		
			Picture picWest = TakePicture(robot);
			PickupAll(robot,picWest);
			Turn(robot,Angle.DEGREES_180);
		
			Picture picEast = TakePicture(robot);
			PickupAll(robot,picEast);
			Turn(robot,Angle.DEGREES_MINUS_90);
		
			uint count = GetMaxAfterPick(picNorth);

			return count;
		}

		private void RunGame(Robot robot)
		{
			uint length;
			while(true)
			{
				if ((length = PickupAll(robot)) == 0)
				{
					Turn(robot,Angle.DEGREES_180);
					Move(robot,count);
					return;
				}
				else
				{
					Move(robot,length);
					count = count + length;
				}
			}
		}

		static void Main(string[] args)
		{
			Game game = new Game();
			Robot robot = Robot.GetRobot();
			game.StartMission(robot);
			game.RunGame(robot);
			game.EndMission(robot);
		}
	}
}
