#if !defined _GAME_H_
#define _GAME_H_

#include <marccppapi.h>
using namespace marc;

#define ERROR_STR_LENGTH 200

class CGame  
{
public:
	CGame();
	virtual ~CGame();
	void DisplayAndExit(Response res);
	void DisplayInfo(CRobotInfo & info);
	Response RunGame(CRobot & robot);
private:
	Response PickupAll(CRobot & robot,CPicture & pic);
	Response PickupAll(CRobot & robot,int & iNextCount);
	int GetMaxAfterPick(CPicture & pic);
	int i_Count;
};

#endif // !defined _GAME_H_
