#include "Game.h"

void main()
{
	CRobot & robot = CRobot::GetRobot();
	CGame game;
	Response res;

	if ((res = robot.StartMission()) != ACTION_SUCCESSFUL)
		game.DisplayAndExit(res);

	if ((res = game.RunGame(robot)) != ACTION_SUCCESSFUL)
		game.DisplayAndExit(res);

	CRobotInfo info;
	if ((res = robot.EndMission(info)) != ACTION_SUCCESSFUL)
		game.DisplayAndExit(res);
	
	game.DisplayInfo(info);
}

