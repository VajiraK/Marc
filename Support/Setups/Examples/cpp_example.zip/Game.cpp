#include <iostream>

#include "Game.h"

using namespace std;

CGame::CGame()
{
	i_Count = 0;
}

CGame::~CGame()
{
}

Response CGame::RunGame(CRobot & robot)
{
	Response res;
	int iCount = 0;
	while(true)
	{
		if ((res = PickupAll(robot,iCount)) != ACTION_SUCCESSFUL)
			return res;
		else
		{
			if (iCount == 0)
			{
				if ((res = robot.Turn(DEGREES_180)) != ACTION_SUCCESSFUL)
					return res;
				else
				{
					if ((res = robot.Move(i_Count)) != ACTION_SUCCESSFUL)
						return res;
					else
						return ACTION_SUCCESSFUL;
				}
			}
			else
			{
				if ((res = robot.Move(iCount)) != ACTION_SUCCESSFUL)
					return res;
				i_Count = i_Count + iCount;
			}
		}
	}
	return ACTION_SUCCESSFUL;
}

void CGame::DisplayAndExit(Response res)
{
	char zBuff[ERROR_STR_LENGTH + 1];
	CMarc::ResponseToStr(res,zBuff,ERROR_STR_LENGTH);
	cout << zBuff << endl;
	exit(0);
}

void CGame::DisplayInfo(CRobotInfo & info)
{
	cout << "Health: " << info.GetHealth() << endl;
	cout << "Battery: " << info.GetRemainingBatteryPower() << endl;
	cout << "Score: " << info.GetScore() << endl;
}

Response CGame::PickupAll(CRobot & robot,CPicture & pic)
{
	int iEnd = pic.GetWidth();
	int jEnd = pic.GetHeight();
	
	for (int i = 0 ; i < iEnd ; i ++)
	{
		for (int j = 0 ; j < jEnd ; j++)
		{
			ObjectType obt = pic.GetObjectTypeAt(i,j);
			if ((obt == OT_YELLOW_PACKAGE) || (obt == OT_PINK_PACKAGE) || (obt == OT_BROWN_PACKAGE) || (obt == OT_BATTERY_PACK))
			{
				Response res;
				if ((res = robot.PickupPackage(i,j,"")) != ACTION_SUCCESSFUL)
					return res;
			}
		}
	}
	return ACTION_SUCCESSFUL;
}

int CGame::GetMaxAfterPick(CPicture & pic)
{
	int iEnd = pic.GetHeight();
	int jEnd = pic.GetWidth();
	int iLength = 5;
	for (int i = 0 ; i < iEnd ; i++)
	{
		for (int j = (jEnd - 1) ; j >= 0 ; j--)
		{
			ObjectType obt = pic.GetObjectTypeAt(i,j);
			if (!((obt == OT_NONE) || (obt == OT_TELEPORT_BEAM) || (obt == OT_YELLOW_PACKAGE) || (obt == OT_PINK_PACKAGE) || (obt == OT_BROWN_PACKAGE) || (obt == OT_BATTERY_PACK)))
			{
				if (iLength > (jEnd - 1 - j))
					iLength = jEnd - 1 - j;
				break;
			}
		}
	}
	return iLength;
}

Response CGame::PickupAll(CRobot & robot,int & iNextCount)
{
	Response res;

	CPicture picNorth;
	if ((res = robot.TakePicture(picNorth)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(robot,picNorth)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = robot.Turn(DEGREES_MINUS_90)) != ACTION_SUCCESSFUL)
		return res;

	CPicture picWest;
	if ((res = robot.TakePicture(picWest)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(robot,picWest)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = robot.Turn(DEGREES_180)) != ACTION_SUCCESSFUL)
		return res;

	CPicture picEast;
	if ((res = robot.TakePicture(picEast)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = PickupAll(robot,picEast)) != ACTION_SUCCESSFUL)
		return res;
	if ((res = robot.Turn(DEGREES_MINUS_90)) != ACTION_SUCCESSFUL)
		return res;

	iNextCount = GetMaxAfterPick(picNorth);
	return ACTION_SUCCESSFUL;
}
