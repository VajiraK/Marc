// This example game doesn't calculate the battery requared to return.
// This goes till a wall or a black package found and returns.

import com.millenniumit.marc.*;

public class Game{

	private int count;

	Game(){
		count = 0;
	}
	
	private void pickupPackage(Robot robot,int i,int j,String tag){
		try{
			robot.pickupPackage(i,j,tag);
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	private Picture takePicture(Robot robot){
		Picture pic;
		try{
			pic = robot.takePicture();
			return pic;
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(UnknownErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		return null;
	}

	private void turn(Robot robot,Angle ang){
		try{
			robot.turn(ang);
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(UnknownErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	private void move(Robot robot,int length){
		try{
			robot.move(length);
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(UnknownErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	private void startMission(Robot robot){
		try{
			robot.startMission();
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(UnknownErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}


	private void endMission(Robot robot){
		try{
			RobotInfo info = robot.endMission();
			displayInfo(info);
		}
		catch(CommunicationFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(CommunicationErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(DisqualifiedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(ActionFailedException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
		catch(UnknownErrorException e){
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	private void pickupAll(Robot robot,Picture pic){

		int iEnd = pic.getWidth();
		int jEnd = pic.getHeight();
	
		for (int i = 0 ; i < iEnd ; i ++){
			for (int j = 0 ; j < jEnd ; j++){
				ObjectType obt = pic.getObjectTypeAt(i,j);
				if (obt.equals(ObjectType.OT_YELLOW_PACKAGE)
				|| obt.equals(ObjectType.OT_PINK_PACKAGE)
				|| obt.equals(ObjectType.OT_BROWN_PACKAGE)
				|| obt.equals(ObjectType.OT_BATTERY_PACK)){
					pickupPackage(robot,i,j,"");
				}
			}
		}
	}	

	private void displayInfo(RobotInfo info){
		System.out.println("Health: " + info.getHealth());
		System.out.println("Battery: " + info.getRemainingBattery());
		System.out.println("Score: " + info.getScore());
	}

	private int getMaxAfterPick(Picture pic){
		int iEnd = pic.getHeight();
		int jEnd = pic.getWidth();
		int iLength = 5;
		for (int i = 0 ; i < iEnd ; i++){
			for (int j = (jEnd - 1) ; j >= 0 ; j--){
				ObjectType obt = pic.getObjectTypeAt(i,j);
				if (!(obt.equals(ObjectType.OT_NONE)
				|| obt.equals(ObjectType.OT_TELEPORT_BEAM)
				|| obt.equals(ObjectType.OT_YELLOW_PACKAGE)
				|| obt.equals(ObjectType.OT_PINK_PACKAGE)
				|| obt.equals(ObjectType.OT_BROWN_PACKAGE)
				|| obt.equals(ObjectType.OT_BATTERY_PACK))){
					if (iLength > (jEnd - 1 - j))
						iLength = jEnd - 1 - j;
					break;
				}
			}
		}
		return iLength;
	} 

	private int pickupAll(Robot robot){

		Picture picNorth = takePicture(robot);
		pickupAll(robot,picNorth);
		turn(robot,Angle.DEGREE_MINUS_90);
		
		Picture picWest = takePicture(robot);
		pickupAll(robot,picWest);
		turn(robot,Angle.DEGREE_180);
		
		Picture picEast = takePicture(robot);
		pickupAll(robot,picEast);
		turn(robot,Angle.DEGREE_MINUS_90);
		
		int count = getMaxAfterPick(picNorth);

		return count;
	}

	private void runGame(Robot robot){
		int length;
		while(true){
			if ((length = pickupAll(robot)) == 0){
				turn(robot,Angle.DEGREE_180);
				move(robot,count);
				return;
			}
			else{
				move(robot,length);
				count = count + length;
			}
		}
	}

	public static void main(String argv[]){
		Game game = new Game();
		Robot robot = Robot.getRobot();
		game.startMission(robot);
		game.runGame(robot);
		game.endMission(robot);
	}
}
